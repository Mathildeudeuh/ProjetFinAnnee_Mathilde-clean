﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;


public class Timer : MonoBehaviour
{
    // A modifier dans l'inspector
    // Valeur du temps
    public float seconde;

    // Valeur du temps
    public float addTime;
    // Booléen
    public bool onTrigger;

    // Afficher le texte
    [SerializeField] private Text myText;

    void Update()
    {
        var end = FindObjectOfType<GameOver>();

        if (onTrigger == false)
        {
            // ... les secondes diminuent
            seconde -= Time.deltaTime;

            /*Affichage du temps*/
            // ... le texte affiche les secondes
            myText.text = Mathf.Round(seconde).ToString();
            
            end.EndOfTheGame();
        }

        // Si onTrigger est vrai
        else
        {
            //myText.text = Mathf.Round(seconde).ToString();
            // ... onTrigger passe en faux
            onTrigger = false;
        }
    }
}