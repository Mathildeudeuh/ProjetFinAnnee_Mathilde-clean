﻿using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerMove : MonoBehaviour
{
    public float speed;
    private Rigidbody2D rb2D;

    public void Move(Vector2 direction)
    {
        direction = direction.normalized;
        rb2D.velocity = direction * speed;
    }
}