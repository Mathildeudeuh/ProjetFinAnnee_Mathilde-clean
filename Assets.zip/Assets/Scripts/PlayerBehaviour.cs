using UnityEngine;
using UnityEngine.InputSystem;

public class PlayerBehaviour : MonoBehaviour
{
    [SerializeField] private float speed;
    [SerializeField] private float maxSpeed;

    private PlayerMove playerMove;
    private Vector2 moveLR;

    private Rigidbody2D body2D;
    private SpriteRenderer sprite;
    private PlayerAnimations animations;
    private PlayerJump playerJump;

    void Start()
    {
        body2D = GetComponent<Rigidbody2D>();
        sprite = GetComponent<SpriteRenderer>();
        playerMove = GetComponent<PlayerMove>();
    }

    public void MoveOnPerformed(InputAction.CallbackContext obj)
    {
        if (!obj.performed)
            animations.MoveOnPerformed();
        moveLR = obj.ReadValue<Vector2>();
        sprite.flipX = (moveLR.x < 0);
    }

    private void FixedUpdate()
    {
        playerMove.Move(moveLR);

    }

    public void JumpOnPerformed(InputAction.CallbackContext obj)
    {
        if (!obj.performed)
            animations.MoveOnPerformed();
        playerJump.Jumping();
    }
}