using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class nvfygfrugtiujgt : MonoBehaviour
{

     void Update()
    {
        Debug.Log("HYYYYEEEEEE AAAHHHH");
    }
}
