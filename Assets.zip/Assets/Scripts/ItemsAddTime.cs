﻿using UnityEngine;

public class ItemsAddTime : MonoBehaviour
{
    private void OnTriggerEnter2D(Collider2D collision)
    {
        AddTime();
    }
    public void AddTime()
    {
        var itemTime = FindObjectOfType<Timer>();
        // seconde prend la valeur de addTime
        itemTime.seconde += itemTime.addTime;
    }
}